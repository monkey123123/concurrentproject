package me.monkey.demo.schedule.util;

import cn.hutool.core.util.ObjectUtil;
import me.monkey.demo.schedule.BadRequestException;

/**
 * 验证工具
 */
public class ValidationUtil{

    /**
     * 验证空
     */
    public static void isNull(Object obj, String entity, String parameter , Object value){
        if(ObjectUtil.isNull(obj)){
            String msg = entity + " 不存在: "+ parameter +" is "+ value;
            throw new BadRequestException(msg);
        }
    }

}
