package me.monkey.demo.schedule;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;

import java.util.List;

/**
 * @author Xuchp
 */
//@Component
public class JobRunner implements ApplicationRunner {

    private final QuartzJobRepository quartzJobRepository;

    private final QuartzManage quartzManage;

    public JobRunner(QuartzJobRepository quartzJobRepository, QuartzManage quartzManage) {
        this.quartzJobRepository = quartzJobRepository;
        this.quartzManage = quartzManage;
    }

    /**
     * 项目启动时重新激活启用的定时任务
     * @param applicationArguments /
     */
    @Override
    public void run(ApplicationArguments applicationArguments){
        System.out.println("--------------------注入定时任务---------------------");
        /*
        QuartzJob job = new QuartzJob();
        job.setJobName("测试任务1");
        job.setIsPause(false);
        // 0 0/1 * * * ? 每三分钟触发一次
        job.setCronExpression("0 0/1 * * * ?");
        job.setBeanName("testTask");
        job.setMethodName("run1");
        quartzJobRepository.save(job);
*/
        List<QuartzJob> quartzJobs = quartzJobRepository.findByIsPauseIsFalse();

        System.out.println("quartzJobs---------------"+quartzJobs);
        quartzJobs.forEach(quartzManage::addJob);
        System.out.println("--------------------定时任务注入完成---------------------");
    }
}