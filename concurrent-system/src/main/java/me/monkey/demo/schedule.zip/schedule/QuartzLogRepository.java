package me.monkey.demo.schedule;

import org.springframework.data.mongodb.repository.MongoRepository;

/**
 */
public interface QuartzLogRepository extends MongoRepository<QuartzLog, String> {
}
