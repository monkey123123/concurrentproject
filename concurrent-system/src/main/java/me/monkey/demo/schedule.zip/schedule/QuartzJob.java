package me.monkey.demo.schedule;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.sql.Timestamp;

//@Getter
//@Setter
@Data
@Document(collection = "quartz_job")
public class QuartzJob  implements Serializable {

    public static final String JOB_KEY = "JOB_KEY";
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;


    /** 定时器名称 */
    private String jobName;

    /** Bean名称 */
    private String beanName;

    /** 方法名称 */
    private String methodName;

    /** 参数 */
    private String params;

    /** cron表达式 */
    private String cronExpression;

    /** 状态 */
    private Boolean isPause = false;

    /** 备注 */
    private String remark;

    private Timestamp createTime;

    public void copy(QuartzJob source){
        BeanUtil.copyProperties(source,this, CopyOptions.create().setIgnoreNullValue(true));
    }
}