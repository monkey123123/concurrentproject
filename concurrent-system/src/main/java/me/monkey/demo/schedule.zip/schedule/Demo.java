package me.monkey.demo.schedule;

import java.util.concurrent.ScheduledThreadPoolExecutor;

public class Demo extends ScheduledThreadPoolExecutor {
    public Demo(int corePoolSize) {
        super(corePoolSize);
    }
    public Demo(int corePoolSize,int max) {
        super(corePoolSize);
    }
}
