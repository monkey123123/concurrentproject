package me.monkey.demo.schedule;

import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 */
public interface QuartzJobRepository extends MongoRepository<QuartzJob, String> {

    /**
     * 查询启用的任务
     * @return List
     */
    List<QuartzJob> findByIsPauseIsFalse();
}
