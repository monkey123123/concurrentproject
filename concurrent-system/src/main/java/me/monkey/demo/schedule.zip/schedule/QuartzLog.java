package me.monkey.demo.schedule;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.sql.Timestamp;

//@Getter
//@Setter
@Data
@Document(collection = "quartz_log")
public class QuartzLog implements Serializable {

    @Id
    private String id;

    /** 任务名称 */
    private String jobName;

    /** Bean名称 */
    private String beanName;

    /** 方法名称 */
    private String methodName;

    /** 参数 */
    private String params;

    /** cron表达式 */
    private String cronExpression;

    /** 状态 */
    private Boolean isSuccess;

    /** 异常详细 */
    private String exceptionDetail;

    /** 耗时（毫秒） */
    private Long time;

    /** 创建日期 */
    private Timestamp createTime;

    public void copy(QuartzLog source){
        BeanUtil.copyProperties(source,this, CopyOptions.create().setIgnoreNullValue(true));
    }
}



